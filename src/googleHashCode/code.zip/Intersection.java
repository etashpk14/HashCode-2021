package googleHashCode;

public class Intersection {

}
