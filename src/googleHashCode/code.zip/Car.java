package googleHashCode;
import java.util.Queue;

public class Car {
	Queue<Street> streets;

	public Car(Queue<Street> streets) {
		this.streets = streets;
	}
}
